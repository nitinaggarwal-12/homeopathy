# Classical Homeopathy Portal — Extended (Embeddings + React + Bilingual)

This project contains:
- FastAPI backend with OpenAI embeddings for Materia Medica search
- Standalone React (Vite + Tailwind) frontend
- Hindi/English bilingual UI
- Classical homeopathic case-taking flow (single-remedy guidance)

## Quick Start

### 1) Backend (FastAPI)
```bash
cd server
cp .env.example .env  # add your OPENAI_API_KEY
python -m venv .venv && source .venv/bin/activate  # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn src.app:app --reload --port 8000
```

### 2) Frontend (React + Vite + Tailwind)
```bash
cd web
npm install
npm run dev  # serves at http://localhost:5173
```

> The frontend talks to backend at `http://localhost:8000` by default. Update `VITE_API_BASE` in `web/.env` if needed.

## Notes
- This is **educational** software; it does **not** replace a physician.
- Emergency symptoms → seek immediate medical care.
