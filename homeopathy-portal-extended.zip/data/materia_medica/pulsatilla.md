Remedy: Pulsatilla
Keynotes:
- Mild, yielding; weepy; seeks consolation; fear to be alone.
- Changeable symptoms; thirstless with dry mouth.
- Aversion to fats; aggravation in warm rooms; desires open air.
- Late, scanty menses; shifting pains.
Modalities: Worse heat; better cool fresh air, gentle motion.
Constitution: Blonde/fair, soft tissue, venous, adaptable.
