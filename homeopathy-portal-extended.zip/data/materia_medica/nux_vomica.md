Remedy: Nux vomica
Keynotes:
- Irritable, oversensitive; business stress; sedentary.
- Gastric issues from stimulants; morning aggravation.
- Coryza evenings/nights; wants warmth; chilliness.
Modalities: Worse morning, cold air; better rest, warmth (except head).
Constitution: Type-A, driven, coffee/alcohol/spice user.
