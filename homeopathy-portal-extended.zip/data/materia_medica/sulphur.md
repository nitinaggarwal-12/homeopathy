Remedy: Sulphur
Keynotes:
- Philosophical, theorizing; neglect of appearance; aversion to bathing.
- Heat aggravation; burning of soles, uncovers feet in bed.
- Desire sweets; 11am hunger; offensive perspiration.
- Skin eruptions: itching, worse warmth of bed.
Modalities: Worse heat, standing; better open air.
Constitution: Lean, stooped, warm-blooded; creative/visionary.
